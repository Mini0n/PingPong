class HomeController < ApplicationController
  def index
  end

  def history
  end

  def log
  end
end
